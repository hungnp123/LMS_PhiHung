﻿namespace Online_Libary
{
    partial class Genres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSearch = new Button();
            txtSearch = new TextBox();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            label7 = new Label();
            label5 = new Label();
            txtGenresname = new TextBox();
            label4 = new Label();
            txtGid = new TextBox();
            dgvGenres = new DataGridView();
            txtDes = new RichTextBox();
            ((System.ComponentModel.ISupportInitialize)dgvGenres).BeginInit();
            SuspendLayout();
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.None;
            btnSearch.BackColor = Color.CornflowerBlue;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnSearch.ForeColor = SystemColors.ButtonHighlight;
            btnSearch.Location = new Point(676, 32);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(100, 30);
            btnSearch.TabIndex = 115;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.None;
            txtSearch.Font = new Font("Segoe UI", 10F);
            txtSearch.Location = new Point(340, 33);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(330, 30);
            txtSearch.TabIndex = 114;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(873, 355);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 40);
            btnCancel.TabIndex = 113;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.None;
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(631, 355);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(120, 40);
            btnDelete.TabIndex = 112;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Anchor = AnchorStyles.None;
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(383, 355);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(120, 40);
            btnUpdate.TabIndex = 111;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.Anchor = AnchorStyles.None;
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(130, 355);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(120, 40);
            btnAdd.TabIndex = 110;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(160, 216);
            label7.Name = "label7";
            label7.Size = new Size(112, 25);
            label7.TabIndex = 109;
            label7.Text = "Description:";
            label7.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(555, 127);
            label5.Name = "label5";
            label5.Size = new Size(127, 25);
            label5.TabIndex = 107;
            label5.Text = "Genres name:";
            // 
            // txtGenresname
            // 
            txtGenresname.Anchor = AnchorStyles.None;
            txtGenresname.Font = new Font("Segoe UI", 10F);
            txtGenresname.Location = new Point(687, 127);
            txtGenresname.Name = "txtGenresname";
            txtGenresname.Size = new Size(258, 30);
            txtGenresname.TabIndex = 106;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(160, 132);
            label4.Name = "label4";
            label4.Size = new Size(98, 25);
            label4.TabIndex = 105;
            label4.Text = "Genres ID:";
            // 
            // txtGid
            // 
            txtGid.Anchor = AnchorStyles.None;
            txtGid.Font = new Font("Segoe UI", 10F);
            txtGid.Location = new Point(263, 130);
            txtGid.Name = "txtGid";
            txtGid.Size = new Size(112, 30);
            txtGid.TabIndex = 104;
            // 
            // dgvGenres
            // 
            dgvGenres.Anchor = AnchorStyles.None;
            dgvGenres.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvGenres.BackgroundColor = Color.WhiteSmoke;
            dgvGenres.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGenres.Location = new Point(12, 441);
            dgvGenres.Name = "dgvGenres";
            dgvGenres.RowHeadersWidth = 51;
            dgvGenres.Size = new Size(1089, 322);
            dgvGenres.TabIndex = 103;
            dgvGenres.CellContentClick += dgvGenres_CellContentClick;
            // 
            // txtDes
            // 
            txtDes.Location = new Point(316, 216);
            txtDes.Name = "txtDes";
            txtDes.Size = new Size(629, 92);
            txtDes.TabIndex = 116;
            txtDes.Text = "";
            // 
            // Genres
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1112, 773);
            Controls.Add(txtDes);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(txtGenresname);
            Controls.Add(label4);
            Controls.Add(txtGid);
            Controls.Add(dgvGenres);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            Name = "Genres";
            Text = "Genres";
            Load += Genres_Load;
            ((System.ComponentModel.ISupportInitialize)dgvGenres).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSearch;
        private TextBox txtSearch;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private Label label7;
        private Label label5;
        private TextBox txtGenresname;
        private Label label4;
        private TextBox txtGid;
        private DataGridView dgvGenres;
        private RichTextBox txtDes;
    }
}