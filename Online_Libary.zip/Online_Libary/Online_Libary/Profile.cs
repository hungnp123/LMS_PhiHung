﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class Profile : Form
    {
        string connectionString;
        SqlConnection con;
        private int ShowUserID;
        public Profile(int Userid)
        {
            InitializeComponent();
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
            ShowUserID = Userid;
        }

        private void Profile_Load(object sender, EventArgs e)
        {
            ShowInfo();
            Avatarload();
        }
        public void Avatarload()
        {
            con.Open();
            string query = "SELECT TOP 1 username FROM Users WHERE userid = @UserID";
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@UserID", ShowUserID);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                lblAvatar.Text = reader["username"].ToString();
            }
            reader.Close();
            con.Close();
        }
        public void ShowInfo()
        {
            string query = "select * from Users where userid =" + ShowUserID;
            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvProfile.DataSource = dataTable;
            con.Close();
        }

        private void dgvProfile_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvProfile.Rows[e.RowIndex];
                txtUid.Text = row.Cells["userid"].Value.ToString();
                txtUname.Text = row.Cells["username"].Value.ToString();
                txtDob.Text = row.Cells["dob"].Value.ToString();
                txtGender.Text = row.Cells["gender"].Value.ToString();
                txtEmail.Text = row.Cells["email"].Value.ToString();
                txtPass.Text = row.Cells["u_password"].Value.ToString();
                lblRole.Text = row.Cells["u_Role"].Value.ToString();
                txtUid.Enabled = false;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string uid = txtUid.Text;
            string name = txtUname.Text;
            string gender = txtGender.Text;
            string dob = txtDob.Text;
            string email = txtEmail.Text;
            string pass = txtPass.Text;
            string update = "update Users set username = '" + name + "', email = '" + email + "', dob = '" + dob + "', gender = '" + gender + "', u_password = '" + pass + "' where userid = '" + uid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtUid.Text = "";
            txtUname.Text = "";
            txtGender.Text = "";
            txtDob.Text = "";
            txtEmail.Text = "";
            txtPass.Text = "";
            lblRole.Text = "";
            txtUid.Enabled = true;
        }
    }
}
