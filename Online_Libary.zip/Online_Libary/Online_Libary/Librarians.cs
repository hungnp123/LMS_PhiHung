﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class Librarians : Form
    {
        string connectionString;
        SqlConnection con;
        public Librarians()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Librarians_Load(object sender, EventArgs e)
        {
            ShowInfo();
        }
        public void ShowInfo()
        {
            try
            {
                string query = "SELECT * from Librarians";
                con.Open();
                DataTable dataTable = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.Fill(dataTable);
                dgvLib.DataSource = dataTable;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eror: " + ex.Message);
            }
        }

        private void dgvLib_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvLib.Rows[e.RowIndex];
                txtLid.Text = row.Cells["lib_id"].Value.ToString();
                txtLibname.Text = row.Cells["lib_name"].Value.ToString();
                txtDob.Text = row.Cells["lib_dob"].Value.ToString();
                txtGender.Text = row.Cells["lib_gender"].Value.ToString();
                txtEmail.Text = row.Cells["lib_email"].Value.ToString();
                txtPhone.Text = row.Cells["lib_phone"].Value.ToString();
                txtLid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string lid = txtLid.Text;
            string name = txtLibname.Text;
            string dob = txtDob.Text;
            string gender = txtGender.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;
            string insert = "insert into Librarians values(" + lid + ", '" + name + "', '" + dob + "','" + gender + "', '" + email + "', '" + phone + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string lid = txtLid.Text;
            string name = txtLibname.Text;
            string dob = txtDob.Text;
            string gender = txtGender.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;
            string update = "update Librarians set lib_name = '" + name + "', lib_dob = '" + dob + "', lib_gender = '" + gender + "', lib_email = '" + email + "', lib_phone = '"+phone+"' where lib_id = '" + lid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete it? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string lid = txtLid.Text;
                string delete = "delete from Librarians where lib_id =" + lid;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfull");
                con.Close();
                ShowInfo();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtLid.Text = "";
            txtLibname.Text = "";
            txtDob.Text = "";
            txtGender.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
            btnAdd.Visible = true;
            txtLid.Enabled = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    string query = "SELECT * FROM Librarians WHERE lib_name LIKE @searchTerm";
                    con.Open();
                    DataTable dataTable = new DataTable();
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                    dgvLib.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please, fill the search box ");
            }
        }
    }
}
