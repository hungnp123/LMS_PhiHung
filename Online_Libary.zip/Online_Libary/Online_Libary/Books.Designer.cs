﻿namespace Online_Libary
{
    partial class Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSearch = new Button();
            txtSearch = new TextBox();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            txtStatus = new Label();
            cbAvailable = new CheckBox();
            label10 = new Label();
            lblAuthor = new Label();
            label9 = new Label();
            lblGenres = new Label();
            label7 = new Label();
            txtPubdate = new TextBox();
            label6 = new Label();
            label5 = new Label();
            txtBookname = new TextBox();
            label4 = new Label();
            txtAid = new TextBox();
            label3 = new Label();
            txtGid = new TextBox();
            label2 = new Label();
            txtBid = new TextBox();
            dgvBook = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvBook).BeginInit();
            SuspendLayout();
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.None;
            btnSearch.BackColor = Color.CornflowerBlue;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnSearch.ForeColor = SystemColors.ButtonHighlight;
            btnSearch.Location = new Point(716, 23);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(100, 30);
            btnSearch.TabIndex = 74;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.None;
            txtSearch.Font = new Font("Segoe UI", 10F);
            txtSearch.Location = new Point(380, 24);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(330, 30);
            txtSearch.TabIndex = 73;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(913, 379);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 40);
            btnCancel.TabIndex = 72;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.None;
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(671, 379);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(120, 40);
            btnDelete.TabIndex = 71;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Anchor = AnchorStyles.None;
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(423, 379);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(120, 40);
            btnUpdate.TabIndex = 70;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.Anchor = AnchorStyles.None;
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(170, 379);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(120, 40);
            btnAdd.TabIndex = 69;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtStatus
            // 
            txtStatus.Anchor = AnchorStyles.None;
            txtStatus.AutoSize = true;
            txtStatus.Font = new Font("Segoe UI", 11F);
            txtStatus.Location = new Point(758, 293);
            txtStatus.Name = "txtStatus";
            txtStatus.Size = new Size(0, 25);
            txtStatus.TabIndex = 68;
            // 
            // cbAvailable
            // 
            cbAvailable.Anchor = AnchorStyles.None;
            cbAvailable.AutoSize = true;
            cbAvailable.Location = new Point(734, 301);
            cbAvailable.Name = "cbAvailable";
            cbAvailable.Size = new Size(18, 17);
            cbAvailable.TabIndex = 67;
            cbAvailable.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11F);
            label10.Location = new Point(615, 294);
            label10.Name = "label10";
            label10.Size = new Size(109, 25);
            label10.TabIndex = 66;
            label10.Text = "Is available:";
            // 
            // lblAuthor
            // 
            lblAuthor.Anchor = AnchorStyles.None;
            lblAuthor.AutoSize = true;
            lblAuthor.Font = new Font("Segoe UI", 11F);
            lblAuthor.Location = new Point(922, 220);
            lblAuthor.Name = "lblAuthor";
            lblAuthor.Size = new Size(56, 25);
            lblAuthor.TabIndex = 65;
            lblAuthor.Text = "(null)";
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11F);
            label9.Location = new Point(842, 220);
            label9.Name = "label9";
            label9.Size = new Size(74, 25);
            label9.TabIndex = 64;
            label9.Text = "Author:";
            // 
            // lblGenres
            // 
            lblGenres.Anchor = AnchorStyles.None;
            lblGenres.AutoSize = true;
            lblGenres.Font = new Font("Segoe UI", 11F);
            lblGenres.Location = new Point(668, 217);
            lblGenres.Name = "lblGenres";
            lblGenres.Size = new Size(56, 25);
            lblGenres.TabIndex = 63;
            lblGenres.Text = "(null)";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(137, 294);
            label7.Name = "label7";
            label7.Size = new Size(153, 25);
            label7.TabIndex = 62;
            label7.Text = "Publication date:";
            // 
            // txtPubdate
            // 
            txtPubdate.Anchor = AnchorStyles.None;
            txtPubdate.Font = new Font("Segoe UI", 10F);
            txtPubdate.Location = new Point(296, 293);
            txtPubdate.Name = "txtPubdate";
            txtPubdate.Size = new Size(214, 30);
            txtPubdate.TabIndex = 61;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(587, 217);
            label6.Name = "label6";
            label6.Size = new Size(75, 25);
            label6.TabIndex = 60;
            label6.Text = "Genres:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(137, 217);
            label5.Name = "label5";
            label5.Size = new Size(110, 25);
            label5.TabIndex = 59;
            label5.Text = "Book name:";
            // 
            // txtBookname
            // 
            txtBookname.Anchor = AnchorStyles.None;
            txtBookname.Font = new Font("Segoe UI", 10F);
            txtBookname.Location = new Point(253, 215);
            txtBookname.Name = "txtBookname";
            txtBookname.Size = new Size(257, 30);
            txtBookname.TabIndex = 58;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(810, 146);
            label4.Name = "label4";
            label4.Size = new Size(97, 25);
            label4.TabIndex = 57;
            label4.Text = "Author ID:";
            // 
            // txtAid
            // 
            txtAid.Anchor = AnchorStyles.None;
            txtAid.Font = new Font("Segoe UI", 10F);
            txtAid.Location = new Point(913, 144);
            txtAid.Name = "txtAid";
            txtAid.Size = new Size(125, 30);
            txtAid.TabIndex = 56;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(475, 147);
            label3.Name = "label3";
            label3.Size = new Size(103, 25);
            label3.TabIndex = 55;
            label3.Text = " Genres ID:";
            // 
            // txtGid
            // 
            txtGid.Anchor = AnchorStyles.None;
            txtGid.Font = new Font("Segoe UI", 10F);
            txtGid.Location = new Point(584, 144);
            txtGid.Name = "txtGid";
            txtGid.Size = new Size(125, 30);
            txtGid.TabIndex = 54;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(137, 145);
            label2.Name = "label2";
            label2.Size = new Size(81, 25);
            label2.TabIndex = 53;
            label2.Text = "Book ID:";
            // 
            // txtBid
            // 
            txtBid.Anchor = AnchorStyles.None;
            txtBid.Font = new Font("Segoe UI", 10F);
            txtBid.Location = new Point(224, 143);
            txtBid.Name = "txtBid";
            txtBid.Size = new Size(125, 30);
            txtBid.TabIndex = 52;
            // 
            // dgvBook
            // 
            dgvBook.Anchor = AnchorStyles.None;
            dgvBook.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBook.BackgroundColor = Color.WhiteSmoke;
            dgvBook.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBook.Location = new Point(52, 458);
            dgvBook.Name = "dgvBook";
            dgvBook.RowHeadersWidth = 51;
            dgvBook.Size = new Size(1089, 306);
            dgvBook.TabIndex = 51;
            dgvBook.CellContentClick += dgvBook_CellContentClick;
            // 
            // Books
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1200, 773);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(txtStatus);
            Controls.Add(cbAvailable);
            Controls.Add(label10);
            Controls.Add(lblAuthor);
            Controls.Add(label9);
            Controls.Add(lblGenres);
            Controls.Add(label7);
            Controls.Add(txtPubdate);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtBookname);
            Controls.Add(label4);
            Controls.Add(txtAid);
            Controls.Add(label3);
            Controls.Add(txtGid);
            Controls.Add(label2);
            Controls.Add(txtBid);
            Controls.Add(dgvBook);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Books";
            Text = "Books";
            Load += Books_Load;
            ((System.ComponentModel.ISupportInitialize)dgvBook).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSearch;
        private TextBox txtSearch;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private Label txtStatus;
        private CheckBox cbAvailable;
        private Label label10;
        private Label lblAuthor;
        private Label label9;
        private Label lblGenres;
        private Label label7;
        private TextBox txtPubdate;
        private Label label6;
        private Label label5;
        private TextBox txtBookname;
        private Label label4;
        private TextBox txtAid;
        private Label label3;
        private TextBox txtGid;
        private Label label2;
        private TextBox txtBid;
        private DataGridView dgvBook;
    }
}