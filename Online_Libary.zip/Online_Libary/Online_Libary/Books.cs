﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class Books : Form
    {
        string connectionString;
        SqlConnection con;
        public Books()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Books_Load(object sender, EventArgs e)
        {
            ShowInfo();
        }
        public void ShowInfo()
        {
            try
            {
                string query = "SELECT Books.book_id, Books.book_name, Books.author_id, Authors.author_name, Books.genre_id, Genres.genres_name, Books.public_date, Books.is_available " +
               "FROM Books " +
               "LEFT JOIN Authors ON Books.author_id = Authors.author_id " +
               "LEFT JOIN Genres ON Books.genre_id = Genres.genres_id;";
                con.Open();
                DataTable dataTable = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.Fill(dataTable);
                dgvBook.DataSource = dataTable;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eror: " + ex.Message);
            }
        }

        private void dgvBook_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvBook.Rows[e.RowIndex];
                txtAid.Text = row.Cells["author_id"].Value.ToString();
                txtBid.Text = row.Cells["book_id"].Value.ToString();
                txtGid.Text = row.Cells["genre_id"].Value.ToString();
                lblGenres.Text = row.Cells["genres_name"].Value.ToString();
                lblAuthor.Text = row.Cells["author_name"].Value.ToString();
                txtPubdate.Text = row.Cells["public_date"].Value.ToString();
                txtBookname.Text = row.Cells["book_name"].Value.ToString();
                txtStatus.Text = row.Cells["is_available"].Value.ToString();
                bool isAvailable = Convert.ToBoolean(row.Cells["is_available"].Value);
                cbAvailable.Checked = isAvailable;
                txtBid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    string query = "SELECT * FROM Books WHERE book_name LIKE @searchTerm";
                    con.Open();
                    DataTable dataTable = new DataTable();
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                    dgvBook.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please, fill the search box ");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string bid = txtBid.Text;
            string aid = txtAid.Text;
            string gid = txtGid.Text;
            string bookname = txtBookname.Text;
            string pubdate = txtPubdate.Text;
            bool isAvailable = cbAvailable.Checked;
            string insert = "insert into Books values(" + bid + ", '" + bookname + "', '" + aid + "','" + gid + "', '" + pubdate + "', " + (isAvailable ? "1" : "0") + ")";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string bid = txtBid.Text;
            string bookname = txtBookname.Text;
            string aid = txtAid.Text;
            string gid = txtGid.Text;
            string pubdate = txtPubdate.Text;
            bool isAvailable = cbAvailable.Checked;
            string update = "update Books set book_name = @BookName, author_id = @AuthorID, genre_id = @GenreID, public_date = @PubDate, is_available = @IsAvailable where book_id = @BookID";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.Parameters.AddWithValue("@BookName", bookname);
            cmd.Parameters.AddWithValue("@AuthorID", aid);
            cmd.Parameters.AddWithValue("@GenreID", gid);
            cmd.Parameters.AddWithValue("@PubDate", pubdate);
            cmd.Parameters.AddWithValue("@IsAvailable", isAvailable ? 1 : 0);
            cmd.Parameters.AddWithValue("@BookID", bid);
            cmd.ExecuteNonQuery();
            con.Close();
            ShowInfo();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete it? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string bid = txtBid.Text;
                string delete = "delete from Books where book_id =" + bid;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfull");
                con.Close();
                ShowInfo();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnAdd.Visible = true;
            txtBid.Enabled = true;
            txtAid.Enabled = true;
            txtGid.Enabled = true;
            cbAvailable.Visible = true;
            txtBid.Text = "";
            txtAid.Text = "";
            txtGid.Text = "";
            txtBookname.Text = "";
            lblAuthor.Text = "(null)";
            lblGenres.Text = "(null)";
            txtPubdate.Text = "";
            cbAvailable.Checked = false;
        }
    }
}
