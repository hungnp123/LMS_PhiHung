﻿namespace Online_Libary
{
    partial class Borrow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSearch = new Button();
            txtSearch = new TextBox();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            lblBookname = new Label();
            label9 = new Label();
            lblLibname = new Label();
            label7 = new Label();
            txtRedate = new TextBox();
            label6 = new Label();
            label5 = new Label();
            txtBorrowdate = new TextBox();
            label4 = new Label();
            txtLid = new TextBox();
            label3 = new Label();
            txtBid = new TextBox();
            label2 = new Label();
            txtBorrowid = new TextBox();
            dgvBorrow = new DataGridView();
            label1 = new Label();
            txtUid = new TextBox();
            lblUsername = new Label();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvBorrow).BeginInit();
            SuspendLayout();
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.None;
            btnSearch.BackColor = Color.CornflowerBlue;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnSearch.ForeColor = SystemColors.ButtonHighlight;
            btnSearch.Location = new Point(679, 24);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(120, 35);
            btnSearch.TabIndex = 98;
            btnSearch.Text = "Search by ID";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.None;
            txtSearch.Font = new Font("Segoe UI", 10F);
            txtSearch.ForeColor = SystemColors.ControlText;
            txtSearch.Location = new Point(343, 27);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(330, 30);
            txtSearch.TabIndex = 97;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(862, 373);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 40);
            btnCancel.TabIndex = 96;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.None;
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(620, 373);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(120, 40);
            btnDelete.TabIndex = 95;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Anchor = AnchorStyles.None;
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(372, 373);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(120, 40);
            btnUpdate.TabIndex = 94;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.Anchor = AnchorStyles.None;
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(119, 373);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(120, 40);
            btnAdd.TabIndex = 93;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // lblBookname
            // 
            lblBookname.Anchor = AnchorStyles.None;
            lblBookname.AutoSize = true;
            lblBookname.Font = new Font("Segoe UI", 11F);
            lblBookname.Location = new Point(488, 220);
            lblBookname.Name = "lblBookname";
            lblBookname.Size = new Size(56, 25);
            lblBookname.TabIndex = 89;
            lblBookname.Text = "(null)";
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11F);
            label9.Location = new Point(372, 220);
            label9.Name = "label9";
            label9.Size = new Size(110, 25);
            label9.TabIndex = 88;
            label9.Text = "Book name:";
            // 
            // lblLibname
            // 
            lblLibname.Anchor = AnchorStyles.None;
            lblLibname.AutoSize = true;
            lblLibname.Font = new Font("Segoe UI", 11F);
            lblLibname.Location = new Point(832, 149);
            lblLibname.Name = "lblLibname";
            lblLibname.Size = new Size(56, 25);
            lblLibname.TabIndex = 87;
            lblLibname.Text = "(null)";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(682, 296);
            label7.Name = "label7";
            label7.Size = new Size(113, 25);
            label7.TabIndex = 86;
            label7.Text = "Return date:";
            // 
            // txtRedate
            // 
            txtRedate.Anchor = AnchorStyles.None;
            txtRedate.Font = new Font("Segoe UI", 10F);
            txtRedate.Location = new Point(804, 295);
            txtRedate.Name = "txtRedate";
            txtRedate.Size = new Size(222, 30);
            txtRedate.TabIndex = 85;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(679, 149);
            label6.Name = "label6";
            label6.Size = new Size(143, 25);
            label6.TabIndex = 84;
            label6.Text = "Librarian name:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(679, 221);
            label5.Name = "label5";
            label5.Size = new Size(119, 25);
            label5.TabIndex = 83;
            label5.Text = "Borrow date:";
            // 
            // txtBorrowdate
            // 
            txtBorrowdate.Anchor = AnchorStyles.None;
            txtBorrowdate.Font = new Font("Segoe UI", 10F);
            txtBorrowdate.Location = new Point(804, 219);
            txtBorrowdate.Name = "txtBorrowdate";
            txtBorrowdate.Size = new Size(222, 30);
            txtBorrowdate.TabIndex = 82;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(372, 150);
            label4.Name = "label4";
            label4.Size = new Size(114, 25);
            label4.TabIndex = 81;
            label4.Text = "Librarian ID:";
            // 
            // txtLid
            // 
            txtLid.Anchor = AnchorStyles.None;
            txtLid.Font = new Font("Segoe UI", 10F);
            txtLid.Location = new Point(492, 149);
            txtLid.Name = "txtLid";
            txtLid.Size = new Size(125, 30);
            txtLid.TabIndex = 80;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(80, 219);
            label3.Name = "label3";
            label3.Size = new Size(86, 25);
            label3.TabIndex = 79;
            label3.Text = " Book ID:";
            // 
            // txtBid
            // 
            txtBid.Anchor = AnchorStyles.None;
            txtBid.Font = new Font("Segoe UI", 10F);
            txtBid.Location = new Point(179, 220);
            txtBid.Name = "txtBid";
            txtBid.Size = new Size(125, 30);
            txtBid.TabIndex = 78;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(80, 150);
            label2.Name = "label2";
            label2.Size = new Size(93, 25);
            label2.TabIndex = 77;
            label2.Text = "Borow ID:";
            // 
            // txtBorrowid
            // 
            txtBorrowid.Anchor = AnchorStyles.None;
            txtBorrowid.Font = new Font("Segoe UI", 10F);
            txtBorrowid.Location = new Point(179, 148);
            txtBorrowid.Name = "txtBorrowid";
            txtBorrowid.Size = new Size(125, 30);
            txtBorrowid.TabIndex = 76;
            // 
            // dgvBorrow
            // 
            dgvBorrow.Anchor = AnchorStyles.None;
            dgvBorrow.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBorrow.BackgroundColor = Color.WhiteSmoke;
            dgvBorrow.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBorrow.Location = new Point(12, 451);
            dgvBorrow.Name = "dgvBorrow";
            dgvBorrow.RowHeadersWidth = 51;
            dgvBorrow.Size = new Size(1089, 306);
            dgvBorrow.TabIndex = 75;
            dgvBorrow.CellContentClick += dgvBorrow_CellContentClick;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(80, 296);
            label1.Name = "label1";
            label1.Size = new Size(77, 25);
            label1.TabIndex = 100;
            label1.Text = "User ID:";
            // 
            // txtUid
            // 
            txtUid.Anchor = AnchorStyles.None;
            txtUid.Font = new Font("Segoe UI", 10F);
            txtUid.Location = new Point(179, 295);
            txtUid.Name = "txtUid";
            txtUid.Size = new Size(125, 30);
            txtUid.TabIndex = 99;
            // 
            // lblUsername
            // 
            lblUsername.Anchor = AnchorStyles.None;
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Segoe UI", 11F);
            lblUsername.Location = new Point(484, 295);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(56, 25);
            lblUsername.TabIndex = 102;
            lblUsername.Text = "(null)";
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11F);
            label10.Location = new Point(372, 295);
            label10.Name = "label10";
            label10.Size = new Size(106, 25);
            label10.TabIndex = 101;
            label10.Text = "User name:";
            // 
            // Borrow
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1112, 773);
            Controls.Add(lblUsername);
            Controls.Add(label10);
            Controls.Add(label1);
            Controls.Add(txtUid);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(lblBookname);
            Controls.Add(label9);
            Controls.Add(lblLibname);
            Controls.Add(label7);
            Controls.Add(txtRedate);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtBorrowdate);
            Controls.Add(label4);
            Controls.Add(txtLid);
            Controls.Add(label3);
            Controls.Add(txtBid);
            Controls.Add(label2);
            Controls.Add(txtBorrowid);
            Controls.Add(dgvBorrow);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            Name = "Borrow";
            Text = "Borrow";
            Load += Borrow_Load;
            ((System.ComponentModel.ISupportInitialize)dgvBorrow).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSearch;
        private TextBox txtSearch;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private Label lblBookname;
        private Label label9;
        private Label lblLibname;
        private Label label7;
        private TextBox txtRedate;
        private Label label6;
        private Label label5;
        private TextBox txtBorrowdate;
        private Label label4;
        private TextBox txtLid;
        private Label label3;
        private TextBox txtBid;
        private Label label2;
        private TextBox txtBorrowid;
        private DataGridView dgvBorrow;
        private Label label1;
        private TextBox txtUid;
        private Label lblUsername;
        private Label label10;
    }
}