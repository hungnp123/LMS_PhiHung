﻿using System.Drawing.Drawing2D;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Online_Libary
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        string connectionString;
        SqlConnection con;
        public Form1()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Resize += new EventHandler(Form1_Load);
            panelLogin.Anchor = AnchorStyles.None;
            panelLogin.Paint += panelLogin_Paint;
            btnLogin.Paint += Login_btn_Paint;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panelLogin.SetBounds((this.ClientSize.Width - panelLogin.Width) / 2, (this.ClientSize.Height - panelLogin.Height) / 2, panelLogin.Width, panelLogin.Height);
        }
        private void panelLogin_Paint(object sender, PaintEventArgs e)
        {
            int cornerRadius = 40; // Bán kính của góc bo (có thể điều chỉnh)
            Panel panel = (Panel)sender;

            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(0, 0, cornerRadius, cornerRadius, 180, 90);
                path.AddArc(panel.Width - cornerRadius, 0, cornerRadius, cornerRadius, 270, 90);
                path.AddArc(panel.Width - cornerRadius, panel.Height - cornerRadius, cornerRadius, cornerRadius, 0, 90);
                path.AddArc(0, panel.Height - cornerRadius, cornerRadius, cornerRadius, 90, 90);
                path.CloseFigure();

                panel.Region = new Region(path);
            }
        }

        private void Login_btn_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string query = "select * from Users where username = '" + username + "' and u_password = '" + password + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rs = cmd.ExecuteReader();
            if (rs.Read())
            {
                int Userid = Convert.ToInt32(rs["userid"]);
                string role = rs["u_role"].ToString();
                if (role.Equals("admin"))
                {
                    Admin adminpage = new Admin();
                    this.Hide();
                    adminpage.ShowDialog();
                    this.Dispose();
                }
                else if (role.Equals("user"))
                {
                    UserForm p = new UserForm(Userid);
                    this.Hide();
                    p.ShowDialog();
                    this.Dispose();
                }
                else
                {
                    MessageBox.Show("You doesn't had any role");
                }
            }
            else
            {
                MessageBox.Show("Usename or password incorect");
            }
            con.Close();
        }
        private void Login_btn_Paint(object sender, PaintEventArgs e)
        {
            int cornerRadius = 10; // Bán kính của góc bo (có thể điều chỉnh)
            Button button = (Button)sender;

            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(0, 0, cornerRadius * 2, cornerRadius * 2, 180, 90);
                path.AddArc(button.Width - cornerRadius * 2, 0, cornerRadius * 2, cornerRadius * 2, 270, 90);
                path.AddArc(button.Width - cornerRadius * 2, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                path.AddArc(0, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                path.CloseFigure();

                button.Region = new Region(path);
            }
        }

    }
}
