﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class Author : Form
    {
        string connectionString;
        SqlConnection con;
        public Author()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Author_Load(object sender, EventArgs e)
        {
            ShowInfo();
        }
        public void ShowInfo()
        {
            try
            {
                string query = "SELECT * from Authors";
                con.Open();
                DataTable dataTable = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.Fill(dataTable);
                dgvAuthor.DataSource = dataTable;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eror: " + ex.Message);
            }
        }
        private void dgvAuthor_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvAuthor.Rows[e.RowIndex];
                txtAid.Text = row.Cells["author_id"].Value.ToString();
                txtAuthorname.Text = row.Cells["author_name"].Value.ToString();
                txtDob.Text = row.Cells["author_dob"].Value.ToString();
                txtGender.Text = row.Cells["author_gender"].Value.ToString();
                txtCountry.Text = row.Cells["author_country"].Value.ToString();
                txtAid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string aid = txtAid.Text;
            string name = txtAuthorname.Text;
            string dob = txtDob.Text;
            string gender = txtGender.Text;
            string country = txtCountry.Text;
            string insert = "insert into Authors values(" + aid + ", '" + name + "', '" + dob + "','" + gender + "', '" + country + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string aid = txtAid.Text;
            string name = txtAuthorname.Text;
            string dob = txtDob.Text;
            string gender = txtGender.Text;
            string country = txtCountry.Text;
            string update = "update Authors set author_name = '" + name + "', author_dob = '" + dob + "', author_gender = '" + gender + "', author_country = '" + country + "' where author_id = '" + aid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete it? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string aid = txtAid.Text;
                string delete = "delete from Authors where author_id =" + aid;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfull");
                con.Close();
                ShowInfo();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtAid.Text = "";
            txtAuthorname.Text = "";
            txtDob.Text = "";
            txtGender.Text = "";
            txtCountry.Text = "";
            btnAdd.Visible = true;
            txtAid.Enabled = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    string query = "SELECT * FROM Authors WHERE author_name LIKE @searchTerm";
                    con.Open();
                    DataTable dataTable = new DataTable();
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                    dgvAuthor.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please, fill the search box ");
            }
        }
    }
}
