﻿namespace Online_Libary
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panelLogin = new Panel();
            btnLogin = new Button();
            pictureBox1 = new PictureBox();
            panel3 = new Panel();
            txtPassword = new TextBox();
            label3 = new Label();
            panel2 = new Panel();
            label2 = new Label();
            txtUsername = new TextBox();
            panelLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panelLogin
            // 
            panelLogin.Anchor = AnchorStyles.None;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelLogin.Controls.Add(btnLogin);
            panelLogin.Controls.Add(pictureBox1);
            panelLogin.Controls.Add(panel3);
            panelLogin.Controls.Add(txtPassword);
            panelLogin.Controls.Add(label3);
            panelLogin.Controls.Add(panel2);
            panelLogin.Controls.Add(label2);
            panelLogin.Controls.Add(txtUsername);
            panelLogin.Location = new Point(341, 102);
            panelLogin.Name = "panelLogin";
            panelLogin.Size = new Size(495, 532);
            panelLogin.TabIndex = 0;
            panelLogin.Paint += panelLogin_Paint;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.OrangeRed;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 11F);
            btnLogin.ForeColor = SystemColors.ButtonHighlight;
            btnLogin.Location = new Point(112, 434);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(280, 55);
            btnLogin.TabIndex = 8;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += Login_btn_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(165, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(159, 86);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.InfoText;
            panel3.Location = new Point(57, 360);
            panel3.Name = "panel3";
            panel3.Size = new Size(377, 1);
            panel3.TabIndex = 4;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.WhiteSmoke;
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Font = new Font("Segoe UI", 10F);
            txtPassword.Location = new Point(57, 331);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(377, 23);
            txtPassword.TabIndex = 6;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(57, 291);
            label3.Name = "label3";
            label3.Size = new Size(95, 25);
            label3.TabIndex = 5;
            label3.Text = "Password:";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.InfoText;
            panel2.Location = new Point(57, 243);
            panel2.Name = "panel2";
            panel2.Size = new Size(377, 1);
            panel2.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(57, 173);
            label2.Name = "label2";
            label2.Size = new Size(109, 25);
            label2.TabIndex = 4;
            label2.Text = "User Name:";
            // 
            // txtUsername
            // 
            txtUsername.BackColor = Color.WhiteSmoke;
            txtUsername.BorderStyle = BorderStyle.None;
            txtUsername.Font = new Font("Segoe UI", 10F);
            txtUsername.Location = new Point(57, 214);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(377, 23);
            txtUsername.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1362, 773);
            Controls.Add(panelLogin);
            DoubleBuffered = true;
            Name = "Form1";
            Text = "Login";
            Load += Form1_Load;
            panelLogin.ResumeLayout(false);
            panelLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelLogin;
        private TextBox txtUsername;
        private Label label2;
        private Panel panel2;
        private Panel panel3;
        private TextBox txtPassword;
        private Label label3;
        private PictureBox pictureBox1;
        private Button btnLogin;
    }
}
