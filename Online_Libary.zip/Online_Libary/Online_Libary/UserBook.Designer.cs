﻿namespace Online_Libary
{
    partial class UserBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PictureBox pictureBox1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserBook));
            btnCancel = new Button();
            btnUpdate = new Button();
            dgvUB = new DataGridView();
            lblAvatar = new Label();
            txtStatus = new Label();
            cbAvailable = new CheckBox();
            label10 = new Label();
            lblAuthor = new Label();
            label9 = new Label();
            lblGenres = new Label();
            label7 = new Label();
            txtPubdate = new TextBox();
            label6 = new Label();
            label5 = new Label();
            txtBookname = new TextBox();
            label2 = new Label();
            txtBid = new TextBox();
            btnSearch = new Button();
            txtSearch = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvUB).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(880, 17);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.TabIndex = 144;
            pictureBox1.TabStop = false;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.BackColor = Color.FromArgb(255, 105, 102);
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(716, 318);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 45);
            btnCancel.TabIndex = 153;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Anchor = AnchorStyles.None;
            btnUpdate.BackColor = Color.FromArgb(255, 105, 102);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(258, 318);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(120, 45);
            btnUpdate.TabIndex = 152;
            btnUpdate.Text = "Borrow";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // dgvUB
            // 
            dgvUB.Anchor = AnchorStyles.None;
            dgvUB.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUB.BackgroundColor = Color.WhiteSmoke;
            dgvUB.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUB.Location = new Point(11, 407);
            dgvUB.Name = "dgvUB";
            dgvUB.RowHeadersWidth = 51;
            dgvUB.Size = new Size(1089, 340);
            dgvUB.TabIndex = 145;
            dgvUB.CellContentClick += dgvUB_CellContentClick;
            // 
            // lblAvatar
            // 
            lblAvatar.AutoSize = true;
            lblAvatar.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAvatar.Location = new Point(946, 26);
            lblAvatar.Name = "lblAvatar";
            lblAvatar.Size = new Size(124, 31);
            lblAvatar.TabIndex = 143;
            lblAvatar.Text = "User name";
            // 
            // txtStatus
            // 
            txtStatus.Anchor = AnchorStyles.None;
            txtStatus.AutoSize = true;
            txtStatus.Font = new Font("Segoe UI", 11F);
            txtStatus.Location = new Point(964, 246);
            txtStatus.Name = "txtStatus";
            txtStatus.Size = new Size(0, 25);
            txtStatus.TabIndex = 170;
            // 
            // cbAvailable
            // 
            cbAvailable.Anchor = AnchorStyles.None;
            cbAvailable.AutoSize = true;
            cbAvailable.Location = new Point(940, 254);
            cbAvailable.Name = "cbAvailable";
            cbAvailable.Size = new Size(18, 17);
            cbAvailable.TabIndex = 169;
            cbAvailable.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11F);
            label10.Location = new Point(821, 247);
            label10.Name = "label10";
            label10.Size = new Size(109, 25);
            label10.TabIndex = 168;
            label10.Text = "Is available:";
            // 
            // lblAuthor
            // 
            lblAuthor.Anchor = AnchorStyles.None;
            lblAuthor.AutoSize = true;
            lblAuthor.Font = new Font("Segoe UI", 11F);
            lblAuthor.Location = new Point(936, 176);
            lblAuthor.Name = "lblAuthor";
            lblAuthor.Size = new Size(56, 25);
            lblAuthor.TabIndex = 167;
            lblAuthor.Text = "(null)";
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11F);
            label9.Location = new Point(856, 176);
            label9.Name = "label9";
            label9.Size = new Size(74, 25);
            label9.TabIndex = 166;
            label9.Text = "Author:";
            // 
            // lblGenres
            // 
            lblGenres.Anchor = AnchorStyles.None;
            lblGenres.AutoSize = true;
            lblGenres.Font = new Font("Segoe UI", 11F);
            lblGenres.Location = new Point(626, 243);
            lblGenres.Name = "lblGenres";
            lblGenres.Size = new Size(56, 25);
            lblGenres.TabIndex = 165;
            lblGenres.Text = "(null)";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(95, 243);
            label7.Name = "label7";
            label7.Size = new Size(153, 25);
            label7.TabIndex = 164;
            label7.Text = "Publication date:";
            // 
            // txtPubdate
            // 
            txtPubdate.Anchor = AnchorStyles.None;
            txtPubdate.Font = new Font("Segoe UI", 10F);
            txtPubdate.Location = new Point(254, 242);
            txtPubdate.Name = "txtPubdate";
            txtPubdate.Size = new Size(214, 30);
            txtPubdate.TabIndex = 163;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(545, 243);
            label6.Name = "label6";
            label6.Size = new Size(75, 25);
            label6.TabIndex = 162;
            label6.Text = "Genres:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(397, 173);
            label5.Name = "label5";
            label5.Size = new Size(110, 25);
            label5.TabIndex = 161;
            label5.Text = "Book name:";
            // 
            // txtBookname
            // 
            txtBookname.Anchor = AnchorStyles.None;
            txtBookname.Font = new Font("Segoe UI", 10F);
            txtBookname.Location = new Point(513, 171);
            txtBookname.Name = "txtBookname";
            txtBookname.Size = new Size(257, 30);
            txtBookname.TabIndex = 160;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(95, 171);
            label2.Name = "label2";
            label2.Size = new Size(81, 25);
            label2.TabIndex = 155;
            label2.Text = "Book ID:";
            // 
            // txtBid
            // 
            txtBid.Anchor = AnchorStyles.None;
            txtBid.Font = new Font("Segoe UI", 10F);
            txtBid.Location = new Point(182, 169);
            txtBid.Name = "txtBid";
            txtBid.Size = new Size(125, 30);
            txtBid.TabIndex = 154;
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.None;
            btnSearch.BackColor = Color.FromArgb(255, 105, 102);
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnSearch.ForeColor = SystemColors.ButtonHighlight;
            btnSearch.Location = new Point(667, 35);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(100, 35);
            btnSearch.TabIndex = 172;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.None;
            txtSearch.Font = new Font("Segoe UI", 10F);
            txtSearch.Location = new Point(331, 37);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(330, 30);
            txtSearch.TabIndex = 171;
            // 
            // UserBook
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnableAllowFocusChange;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1112, 733);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(txtStatus);
            Controls.Add(cbAvailable);
            Controls.Add(label10);
            Controls.Add(lblAuthor);
            Controls.Add(label9);
            Controls.Add(lblGenres);
            Controls.Add(label7);
            Controls.Add(txtPubdate);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtBookname);
            Controls.Add(label2);
            Controls.Add(txtBid);
            Controls.Add(btnCancel);
            Controls.Add(btnUpdate);
            Controls.Add(dgvUB);
            Controls.Add(pictureBox1);
            Controls.Add(lblAvatar);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UserBook";
            Text = "UserBook";
            Load += UserBook_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvUB).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnCancel;
        private Button btnUpdate;
        private DataGridView dgvUB;
        private Label lblAvatar;
        private Label txtStatus;
        private CheckBox cbAvailable;
        private Label label10;
        private Label lblAuthor;
        private Label label9;
        private Label lblGenres;
        private Label label7;
        private TextBox txtPubdate;
        private Label label6;
        private Label label5;
        private TextBox txtBookname;
        private Label label2;
        private TextBox txtBid;
        private Button btnSearch;
        private TextBox txtSearch;
    }
}