﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class Borrow : Form
    {
        string connectionString;
        SqlConnection con;
        public Borrow()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Borrow_Load(object sender, EventArgs e)
        {
            ShowInfo();
            txtBorrowid.Enabled = false;
        }
        public void ShowInfo()
        {
            try
            {
                string query = "SELECT Borrows.borrow_id, Borrows.book_id, Books.book_name, Borrows.userid, Users.username, Borrows.lib_id,  Librarians.lib_name, Borrows.loan_date, Borrows.due_date " +
              "FROM Borrows " +
              "LEFT JOIN Users ON Borrows.userid = Users.userid " +
              "LEFT JOIN Librarians ON Borrows.lib_id = Librarians.lib_id " +
              "LEFT JOIN Books ON Borrows.book_id = Books.book_id;";
                con.Open();
                DataTable dataTable = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.Fill(dataTable);
                dgvBorrow.DataSource = dataTable;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eror: " + ex.Message);
            }
        }

        private void dgvBorrow_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvBorrow.Rows[e.RowIndex];
                txtUid.Text = row.Cells["userid"].Value.ToString();
                txtLid.Text = row.Cells["lib_id"].Value.ToString();
                txtBorrowid.Text = row.Cells["borrow_id"].Value.ToString();
                txtBid.Text = row.Cells["book_id"].Value.ToString();
                lblBookname.Text = row.Cells["book_name"].Value.ToString();
                lblUsername.Text = row.Cells["username"].Value.ToString();
                lblLibname.Text = row.Cells["lib_name"].Value.ToString();
                txtBorrowdate.Text = row.Cells["loan_date"].Value.ToString();
                txtRedate.Text = row.Cells["due_date"].Value.ToString();
                txtBorrowid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string lid = txtLid.Text;
            string uid = txtUid.Text;
            string bid = txtBid.Text;
            string Bodate = txtBorrowdate.Text;
            string Redate = txtRedate.Text;
            string insert = "insert into Borrows (book_id, userid, lib_id, loan_date, due_date) values('" + bid + "','" + uid + "','" + lid + "', '" + Bodate + "', '" + Redate + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string boid = txtBorrowid.Text;
            string lid = txtLid.Text;
            string uid = txtUid.Text;
            string bid = txtBid.Text;
            string Bodate = txtBorrowdate.Text;
            string Redate = txtRedate.Text;
            string update = "update Borrows set lib_id = '" + lid + "', userid = '" + uid + "', book_id = '" + bid + "', loan_date = '" + Bodate + "', due_date = '" + Redate + "' where borrow_id = '" + boid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfull");
            con.Close();
            ShowInfo();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete it? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string boid = txtBorrowid.Text;
                string delete = "delete from Borrows where borrow_id =" + boid;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfull");
                con.Close();
                ShowInfo();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnAdd.Visible = true;
            txtLid.Enabled = true;
            txtBid.Enabled = true;
            txtUid.Enabled = true;
            txtBorrowid.Enabled = false;
            txtLid.Text = "";
            txtBid.Text = "";
            txtUid.Text = "";
            txtBorrowid.Text = "";
            txtBorrowdate.Text = "";
            txtRedate.Text = "";
            lblBookname.Text = "(null)";
            lblUsername.Text = "(null)";
            lblLibname.Text = "(null)";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    string query = "SELECT * FROM Borrows WHERE borrow_id LIKE @searchTerm";
                    con.Open();
                    DataTable dataTable = new DataTable();
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                    dgvBorrow.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please, fill the search box ");
            }
        }
    }
}
