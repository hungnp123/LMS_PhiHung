﻿namespace Online_Libary
{
    partial class Borrowing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PictureBox pictureBox1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Borrowing));
            dgvBorrowing = new DataGridView();
            btnSearch = new Button();
            txtSearch = new TextBox();
            lblAvatar = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvBorrowing).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(872, 35);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.TabIndex = 174;
            pictureBox1.TabStop = false;
            // 
            // dgvBorrowing
            // 
            dgvBorrowing.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBorrowing.BackgroundColor = Color.WhiteSmoke;
            dgvBorrowing.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBorrowing.Dock = DockStyle.Bottom;
            dgvBorrowing.Location = new Point(0, 396);
            dgvBorrowing.Name = "dgvBorrowing";
            dgvBorrowing.RowHeadersWidth = 51;
            dgvBorrowing.Size = new Size(1112, 337);
            dgvBorrowing.TabIndex = 146;
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.None;
            btnSearch.BackColor = Color.FromArgb(255, 105, 102);
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnSearch.ForeColor = SystemColors.ButtonHighlight;
            btnSearch.Location = new Point(659, 53);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(100, 35);
            btnSearch.TabIndex = 176;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.None;
            txtSearch.Font = new Font("Segoe UI", 10F);
            txtSearch.Location = new Point(323, 55);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(330, 30);
            txtSearch.TabIndex = 175;
            // 
            // lblAvatar
            // 
            lblAvatar.AutoSize = true;
            lblAvatar.BackColor = Color.Transparent;
            lblAvatar.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAvatar.Location = new Point(938, 44);
            lblAvatar.Name = "lblAvatar";
            lblAvatar.Size = new Size(124, 31);
            lblAvatar.TabIndex = 173;
            lblAvatar.Text = "User name";
            // 
            // Borrowing
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1112, 733);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(pictureBox1);
            Controls.Add(lblAvatar);
            Controls.Add(dgvBorrowing);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Borrowing";
            Text = "Borrowing";
            Load += Borrowing_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvBorrowing).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvBorrowing;
        private Button btnSearch;
        private TextBox txtSearch;
        private Label lblAvatar;
    }
}