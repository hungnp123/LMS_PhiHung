﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class UserForm : Form
    {
        private int ShowUserID;
        private Dictionary<Button, Color> buttonColors = new Dictionary<Button, Color>();
        public UserForm(int Userid)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            ShowUserID = Userid;
        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            buttonColors.Add(button1, button1.BackColor);
            buttonColors.Add(button4, button4.BackColor);
            buttonColors.Add(button5, button5.BackColor);
            button5.BackColor = Color.Crimson;
            loadform(new Profile(ShowUserID));
        }
        public void loadform(object Form)
        {
            if (this.mainpanel.Controls.Count > 0)
                this.mainpanel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainpanel.Controls.Add(f);
            this.mainpanel.Tag = f;
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            loadform(new Profile(ShowUserID));
            ChangeButtonColor(button5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadform(new UserBook(ShowUserID));
            ChangeButtonColor(button1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            loadform(new Borrowing(ShowUserID));
            ChangeButtonColor(button4);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Form1 logout = new Form1();
            this.Hide();
            logout.ShowDialog();
            this.Dispose();
        }
        private void ChangeButtonColor(Button selectedButton)
        {
            foreach (var button in buttonColors.Keys)
            {
                if (button == selectedButton)
                {
                    button.BackColor = Color.Crimson;
                }
                else
                {
                    button.BackColor = buttonColors[button];
                }
            }
        }
    }
}
