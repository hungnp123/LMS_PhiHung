﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class Borrowing : Form
    {
        string connectionString;
        SqlConnection con;
        private int ShowUserID;
        public Borrowing(int Userid)
        {
            InitializeComponent();
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
            ShowUserID = Userid;
        }

        private void Borrowing_Load(object sender, EventArgs e)
        {
            ShowInfo();
            Avatarload();
        }
        public void Avatarload()
        {
            con.Open();
            string query = "SELECT TOP 1 username FROM Users WHERE userid = @UserID";
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@UserID", ShowUserID);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                lblAvatar.Text = reader["username"].ToString();
            }
            reader.Close();
            con.Close();
        }
        public void ShowInfo()
        {
            string query = "SELECT a.username AS UserName, b.book_name AS Book, c.loan_date AS BorrowDate, c.due_date AS ReturnDate, l.lib_name AS Librarian " +
                  "FROM Borrows c " +
                  "JOIN Books b ON c.book_id = b.book_id " +
                  "JOIN Librarians l ON c.lib_id = l.lib_id " +
                  "JOIN Users a ON c.userid = a.userid " +
                  "WHERE a.userid = " + ShowUserID;

            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvBorrowing.DataSource = dataTable;
            con.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    string query = "SELECT * FROM Books WHERE book_name LIKE @searchTerm";
                    con.Open();
                    DataTable dataTable = new DataTable();
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                    dgvBorrowing.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please, fill the search box ");
            }
        }
    }
}
