﻿namespace Online_Libary
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PictureBox pictureBox1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Profile));
            lblAvatar = new Label();
            label3 = new Label();
            txtPass = new TextBox();
            label2 = new Label();
            txtEmail = new TextBox();
            label1 = new Label();
            txtGender = new TextBox();
            btnCancel = new Button();
            btnUpdate = new Button();
            label7 = new Label();
            txtDob = new TextBox();
            label5 = new Label();
            txtUname = new TextBox();
            label4 = new Label();
            txtUid = new TextBox();
            dgvProfile = new DataGridView();
            label6 = new Label();
            lblRole = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvProfile).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(874, 22);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // lblAvatar
            // 
            lblAvatar.AutoSize = true;
            lblAvatar.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAvatar.Location = new Point(940, 31);
            lblAvatar.Name = "lblAvatar";
            lblAvatar.Size = new Size(124, 31);
            lblAvatar.TabIndex = 0;
            lblAvatar.Text = "User name";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(88, 298);
            label3.Name = "label3";
            label3.Size = new Size(95, 25);
            label3.TabIndex = 140;
            label3.Text = "Password:";
            // 
            // txtPass
            // 
            txtPass.Anchor = AnchorStyles.None;
            txtPass.Font = new Font("Segoe UI", 10F);
            txtPass.Location = new Point(210, 297);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(241, 30);
            txtPass.TabIndex = 139;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(506, 218);
            label2.Name = "label2";
            label2.Size = new Size(62, 25);
            label2.TabIndex = 138;
            label2.Text = "Email:";
            // 
            // txtEmail
            // 
            txtEmail.Anchor = AnchorStyles.None;
            txtEmail.Font = new Font("Segoe UI", 10F);
            txtEmail.Location = new Point(574, 218);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(262, 30);
            txtEmail.TabIndex = 137;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(834, 301);
            label1.Name = "label1";
            label1.Size = new Size(78, 25);
            label1.TabIndex = 136;
            label1.Text = "Gender:";
            // 
            // txtGender
            // 
            txtGender.Anchor = AnchorStyles.None;
            txtGender.Font = new Font("Segoe UI", 10F);
            txtGender.Location = new Point(918, 299);
            txtGender.Name = "txtGender";
            txtGender.Size = new Size(99, 30);
            txtGender.TabIndex = 135;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.BackColor = Color.FromArgb(255, 105, 102);
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(716, 384);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 45);
            btnCancel.TabIndex = 132;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Anchor = AnchorStyles.None;
            btnUpdate.BackColor = Color.FromArgb(255, 105, 102);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(258, 384);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(120, 45);
            btnUpdate.TabIndex = 130;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(506, 302);
            label7.Name = "label7";
            label7.Size = new Size(51, 25);
            label7.TabIndex = 128;
            label7.Text = "DoB:";
            // 
            // txtDob
            // 
            txtDob.Anchor = AnchorStyles.None;
            txtDob.Font = new Font("Segoe UI", 10F);
            txtDob.Location = new Point(574, 298);
            txtDob.Name = "txtDob";
            txtDob.Size = new Size(214, 30);
            txtDob.TabIndex = 127;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(88, 219);
            label5.Name = "label5";
            label5.Size = new Size(106, 25);
            label5.TabIndex = 126;
            label5.Text = "User name:";
            // 
            // txtUname
            // 
            txtUname.Anchor = AnchorStyles.None;
            txtUname.Font = new Font("Segoe UI", 10F);
            txtUname.Location = new Point(210, 218);
            txtUname.Name = "txtUname";
            txtUname.Size = new Size(241, 30);
            txtUname.TabIndex = 125;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(88, 142);
            label4.Name = "label4";
            label4.Size = new Size(77, 25);
            label4.TabIndex = 124;
            label4.Text = "User ID:";
            // 
            // txtUid
            // 
            txtUid.Anchor = AnchorStyles.None;
            txtUid.Font = new Font("Segoe UI", 10F);
            txtUid.Location = new Point(210, 140);
            txtUid.Name = "txtUid";
            txtUid.Size = new Size(111, 30);
            txtUid.TabIndex = 123;
            // 
            // dgvProfile
            // 
            dgvProfile.Anchor = AnchorStyles.None;
            dgvProfile.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvProfile.BackgroundColor = Color.WhiteSmoke;
            dgvProfile.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProfile.Location = new Point(12, 468);
            dgvProfile.Name = "dgvProfile";
            dgvProfile.RowHeadersWidth = 51;
            dgvProfile.Size = new Size(1089, 293);
            dgvProfile.TabIndex = 122;
            dgvProfile.CellContentClick += dgvProfile_CellContentClick;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(506, 142);
            label6.Name = "label6";
            label6.Size = new Size(52, 25);
            label6.TabIndex = 141;
            label6.Text = "Role:";
            // 
            // lblRole
            // 
            lblRole.Anchor = AnchorStyles.None;
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Segoe UI", 11F);
            lblRole.Location = new Point(574, 141);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(56, 25);
            lblRole.TabIndex = 142;
            lblRole.Text = "(null)";
            // 
            // Profile
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1112, 773);
            Controls.Add(lblRole);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(txtPass);
            Controls.Add(label2);
            Controls.Add(txtEmail);
            Controls.Add(label1);
            Controls.Add(txtGender);
            Controls.Add(btnCancel);
            Controls.Add(btnUpdate);
            Controls.Add(label7);
            Controls.Add(txtDob);
            Controls.Add(label5);
            Controls.Add(txtUname);
            Controls.Add(label4);
            Controls.Add(txtUid);
            Controls.Add(dgvProfile);
            Controls.Add(pictureBox1);
            Controls.Add(lblAvatar);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Profile";
            Text = "Profile";
            Load += Profile_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvProfile).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAvatar;
        private Label label3;
        private TextBox txtPass;
        private Label label2;
        private TextBox txtEmail;
        private Label label1;
        private TextBox txtGender;
        private Button btnCancel;
        private Button btnUpdate;
        private Label label7;
        private TextBox txtDob;
        private Label label5;
        private TextBox txtUname;
        private Label label4;
        private TextBox txtUid;
        private DataGridView dgvProfile;
        private Label label6;
        private Label lblRole;
    }
}