﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Libary
{
    public partial class Genres : Form
    {
        string connectionString;
        SqlConnection con;
        public Genres()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Genres_Load(object sender, EventArgs e)
        {
            ShowInfo();
        }
        public void ShowInfo()
        {
            try
            {
                string query = "SELECT * from Genres";
                con.Open();
                DataTable dataTable = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.Fill(dataTable);
                dgvGenres.DataSource = dataTable;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eror: " + ex.Message);
            }
        }

        private void dgvGenres_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvGenres.Rows[e.RowIndex];
                txtGid.Text = row.Cells["genres_id"].Value.ToString();
                txtGenresname.Text = row.Cells["genres_name"].Value.ToString();
                txtDes.Text = row.Cells["genres_des"].Value.ToString();
                txtGid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string id = txtGid.Text;
            string name = txtGenresname.Text;
            string des = txtDes.Text;
            string insert = "insert into Genres values(" + id + ", '" + name + "', '" + des + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfully");
            con.Close();
            ShowInfo();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string id = txtGid.Text;
            string name = txtGenresname.Text;
            string des = txtDes.Text;
            string update = "update Genres set genres_name = '" + name + "', genres_des = '" + des + "' where genres_id = '" + id + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfully");
            con.Close();
            ShowInfo();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete it? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string id = txtGid.Text;
                string delete = "delete from Genres where genres_id =" + id;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");
                con.Close();
                ShowInfo();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtGid.Text = "";
            txtGenresname.Text = "";
            txtDes.Text = "";
            btnAdd.Visible = true;
            txtGid.Enabled = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    string query = "SELECT * FROM Genres WHERE genres_name LIKE @searchTerm";
                    con.Open();
                    DataTable dataTable = new DataTable();
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                    dgvGenres.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please, fill the search box ");
            }
        }
    }
}
