﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Online_Libary
{
    public partial class UserBook : Form
    {
        string connectionString;
        SqlConnection con;
        private int ShowUserID;
        public UserBook(int Userid)
        {
            InitializeComponent();
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Library_Management; Integrated Security = True";
            con = new SqlConnection(connectionString);
            ShowUserID = Userid;
        }

        private void UserBook_Load(object sender, EventArgs e)
        {
            ShowInfo();
            Avatarload();
        }
        public void Avatarload()
        {
            con.Open();
            string query = "SELECT TOP 1 username FROM Users WHERE userid = @UserID";
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@UserID", ShowUserID);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                lblAvatar.Text = reader["username"].ToString();
            }
            reader.Close();
            con.Close();
        }
        public void ShowInfo()
        {
            string query = "SELECT Books.book_id, Books.book_name, Books.author_id, Authors.author_name, Books.genre_id, Genres.genres_name, Books.public_date, Books.is_available " +
               "FROM Books " +
               "LEFT JOIN Authors ON Books.author_id = Authors.author_id " +
               "LEFT JOIN Genres ON Books.genre_id = Genres.genres_id " +
               "WHERE Books.is_available = 1";
            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvUB.DataSource = dataTable;
            con.Close();
        }
        private void dgvUB_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvUB.Rows[e.RowIndex];
                txtBid.Text = row.Cells["book_id"].Value.ToString();
                lblGenres.Text = row.Cells["genres_name"].Value.ToString();
                lblAuthor.Text = row.Cells["author_name"].Value.ToString();
                txtPubdate.Text = row.Cells["public_date"].Value.ToString();
                txtBookname.Text = row.Cells["book_name"].Value.ToString();
                txtStatus.Text = row.Cells["is_available"].Value.ToString();
                bool isAvailable = Convert.ToBoolean(row.Cells["is_available"].Value);
                cbAvailable.Checked = isAvailable;
                txtBid.Enabled = false;
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int randomLibId = random.Next(1, 7);
            string lid = randomLibId.ToString();
            int userId = ShowUserID;
            string bid = txtBid.Text;
            string uid = userId.ToString();
            string Bodate = DateTime.Now.ToString();
            string Redate = DateTime.Now.AddDays(7).ToString(); ;
            string insert = "insert into Borrows (book_id, userid, lib_id, loan_date, due_date) values('" + bid + "','" + uid + "','" + lid + "', '" + Bodate + "', '" + Redate + "')";
            bool isAvailable = cbAvailable.Checked;
            string update = "update Books set is_available = 0 where book_id = '" + bid + "'";
            con.Open();
            SqlCommand insertCmd = new SqlCommand(insert, con);
            SqlCommand updatecmd = new SqlCommand(update, con);
            insertCmd.ExecuteNonQuery();
            updatecmd.ExecuteNonQuery();
            MessageBox.Show("Borrow succesful");
            con.Close();
            ShowInfo();
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtBid.Enabled = true;
            txtBookname.Text = "";
            txtBid.Text = "";
            txtPubdate.Text = "";
            lblAuthor.Text = "(null)";
            lblGenres.Text = "(null)";
            cbAvailable.Checked = false;
            txtStatus.Text = "";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    string query = "SELECT * FROM Books WHERE book_name LIKE @searchTerm";
                    con.Open();
                    DataTable dataTable = new DataTable();
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                    dgvUB.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please, fill the search box ");
            }
        }
    }
}
