﻿namespace Online_Libary
{
    partial class Author
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSearch = new Button();
            txtSearch = new TextBox();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            label7 = new Label();
            txtDob = new TextBox();
            label5 = new Label();
            txtAuthorname = new TextBox();
            label4 = new Label();
            txtAid = new TextBox();
            dgvAuthor = new DataGridView();
            label1 = new Label();
            txtGender = new TextBox();
            label2 = new Label();
            txtCountry = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvAuthor).BeginInit();
            SuspendLayout();
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.None;
            btnSearch.BackColor = Color.CornflowerBlue;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnSearch.ForeColor = SystemColors.ButtonHighlight;
            btnSearch.Location = new Point(676, 26);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(100, 30);
            btnSearch.TabIndex = 98;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.None;
            txtSearch.Font = new Font("Segoe UI", 10F);
            txtSearch.Location = new Point(340, 27);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(330, 30);
            txtSearch.TabIndex = 97;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(873, 349);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 40);
            btnCancel.TabIndex = 96;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.None;
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(631, 349);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(120, 40);
            btnDelete.TabIndex = 95;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Anchor = AnchorStyles.None;
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(383, 349);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(120, 40);
            btnUpdate.TabIndex = 94;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.Anchor = AnchorStyles.None;
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(130, 349);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(120, 40);
            btnAdd.TabIndex = 93;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(71, 239);
            label7.Name = "label7";
            label7.Size = new Size(122, 25);
            label7.TabIndex = 86;
            label7.Text = "Date of Birth:";
            // 
            // txtDob
            // 
            txtDob.Anchor = AnchorStyles.None;
            txtDob.Font = new Font("Segoe UI", 10F);
            txtDob.Location = new Point(199, 238);
            txtDob.Name = "txtDob";
            txtDob.Size = new Size(214, 30);
            txtDob.TabIndex = 85;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(347, 140);
            label5.Name = "label5";
            label5.Size = new Size(126, 25);
            label5.TabIndex = 83;
            label5.Text = "Author name:";
            // 
            // txtAuthorname
            // 
            txtAuthorname.Anchor = AnchorStyles.None;
            txtAuthorname.Font = new Font("Segoe UI", 10F);
            txtAuthorname.Location = new Point(479, 140);
            txtAuthorname.Name = "txtAuthorname";
            txtAuthorname.Size = new Size(258, 30);
            txtAuthorname.TabIndex = 82;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(71, 142);
            label4.Name = "label4";
            label4.Size = new Size(97, 25);
            label4.TabIndex = 81;
            label4.Text = "Author ID:";
            // 
            // txtAid
            // 
            txtAid.Anchor = AnchorStyles.None;
            txtAid.Font = new Font("Segoe UI", 10F);
            txtAid.Location = new Point(174, 140);
            txtAid.Name = "txtAid";
            txtAid.Size = new Size(112, 30);
            txtAid.TabIndex = 80;
            // 
            // dgvAuthor
            // 
            dgvAuthor.Anchor = AnchorStyles.None;
            dgvAuthor.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAuthor.BackgroundColor = Color.WhiteSmoke;
            dgvAuthor.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAuthor.Location = new Point(12, 435);
            dgvAuthor.Name = "dgvAuthor";
            dgvAuthor.RowHeadersWidth = 51;
            dgvAuthor.Size = new Size(1089, 322);
            dgvAuthor.TabIndex = 75;
            dgvAuthor.CellContentClick += dgvAuthor_CellContentClick;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(802, 142);
            label1.Name = "label1";
            label1.Size = new Size(78, 25);
            label1.TabIndex = 100;
            label1.Text = "Gender:";
            // 
            // txtGender
            // 
            txtGender.Anchor = AnchorStyles.None;
            txtGender.Font = new Font("Segoe UI", 10F);
            txtGender.Location = new Point(886, 140);
            txtGender.Name = "txtGender";
            txtGender.Size = new Size(129, 30);
            txtGender.TabIndex = 99;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(514, 240);
            label2.Name = "label2";
            label2.Size = new Size(83, 25);
            label2.TabIndex = 102;
            label2.Text = "Country:";
            // 
            // txtCountry
            // 
            txtCountry.Anchor = AnchorStyles.None;
            txtCountry.Font = new Font("Segoe UI", 10F);
            txtCountry.Location = new Point(603, 239);
            txtCountry.Name = "txtCountry";
            txtCountry.Size = new Size(214, 30);
            txtCountry.TabIndex = 101;
            // 
            // Author
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1112, 773);
            Controls.Add(label2);
            Controls.Add(txtCountry);
            Controls.Add(label1);
            Controls.Add(txtGender);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(label7);
            Controls.Add(txtDob);
            Controls.Add(label5);
            Controls.Add(txtAuthorname);
            Controls.Add(label4);
            Controls.Add(txtAid);
            Controls.Add(dgvAuthor);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            Name = "Author";
            Text = "Author";
            Load += Author_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAuthor).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSearch;
        private TextBox txtSearch;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private Label label7;
        private TextBox txtDob;
        private Label label5;
        private TextBox txtAuthorname;
        private Label label4;
        private TextBox txtAid;
        private DataGridView dgvAuthor;
        private Label label1;
        private TextBox txtGender;
        private Label label2;
        private TextBox txtCountry;
    }
}